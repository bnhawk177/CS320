import org.junit.Test;

public class TaskTest {

	  @Test 
	  public void createValidTaskData() {
	      Task task = new Task("1", "Playing", "Play Soccer");
	      System.out.println(task);
	   }
	   
	}
