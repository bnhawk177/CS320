package contact;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

// The Junit Class helps test the ContactService class and the methods within.

public class ContactServiceTest {

// Test the add methods.

@Test

public void testAdd(){

ContactService cs = new ContactService();

Contact t1 = new Contact("74231", "Jane", "Doe", "916", "Chesapeake");

assertEquals(true, cs.addContact(t1));

}

// Test the delete methods.

@Test

public void testDelete(){

ContactService cs = new ContactService();

Contact t1 = new Contact("74231", "Jane", "Doe", "916", "Chesapeake");

Contact t2 = new Contact("233544", "John", "Doe", "606", "Brookwood");

Contact t3 = new Contact("711231", "Joey", "Doe", "511", "Remount");

cs.addContact(t1);

cs.addContact(t2);

cs.addContact(t3);

assertEquals(true, cs.deleteContact("233544"));

assertEquals(false, cs.deleteContact("74231"));

assertEquals(false, cs.deleteContact("233544"));

}

// Test the update methods.

@Test

public void testUpdate(){

ContactService cs = new ContactService();

Contact t1 = new Contact("74231", "Jane", "Doe", "916", "Chesapeake");

Contact t2 = new Contact("233544", "John", "Doe", "606", "Brookwood");

Contact t3 = new Contact("711231", "Joey", "Doe", "511", "Remount");

cs.addContact(t1);

cs.addContact(t2);

cs.addContact(t3);

assertEquals(true, cs.updateContact("711231", "JoeyFirst", "DoeLast", "511", "Remount"));

assertEquals(false, cs.updateContact("7112361", "JoeyFirst", "DoeLast", "511", "Remount"));

}

}