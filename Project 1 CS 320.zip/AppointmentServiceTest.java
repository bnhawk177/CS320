import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.List;

public class AppointmentServiceTest {
    @Test
    public void testAddAppointment() {
        AppointmentService appointmentService = new AppointmentService();

        // Add new appointment
        Date appointmentDate = new Date();
        String appointmentID = "1234567890";
        String description = "This is a test appointment.";
        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
        appointmentService.addAppointment(appointment);

        // Try to add appointment with same ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment));

        // Try to add null appointment
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(null));

        List<Appointment> appointments = appointmentService.getAppointments();
        Assertions.assertEquals(1, appointments.size());
        Assertions.assertEquals(appointment, appointments.get(0));
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService appointmentService = new AppointmentService();

        // Add new appointment
        Date appointmentDate = new Date();
        String appointmentID = "1234567890";
        String description = "This is a test appointment.";
        Appointment appointment = new Appointment(appointmentID, appointmentDate, description);
        appointmentService.addAppointment(appointment);

        // Try to delete appointment with null ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment(null));

        // Try to delete appointment with non-existing ID
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("0987654321"));

        // Delete existing appointment
        appointmentService.deleteAppointment(appointmentID);
        List<Appointment> appointments = appointmentService.getAppointments();
        Assertions.assertEquals(0, appointments.size());
    }
}