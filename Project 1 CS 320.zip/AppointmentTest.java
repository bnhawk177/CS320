import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testCreateAppointment() {
        Appointment appointment = new Appointment("12345", new Date(), "test appointment");
        assertNotNull(appointment);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidAppointmentId() {
        Appointment appointment = new Appointment("12345678901", new Date(), "test appointment");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNullAppointmentId() {
        Appointment appointment = new Appointment(null, new Date(), "test appointment");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNullAppointmentDate() {
        Appointment appointment = new Appointment("12345", null, "test appointment");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPastAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
        Appointment appointment = new Appointment("12345", pastDate, "test appointment");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testLongDescription() {
        String longDescription = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vitae sem vel mauris tempus dictum. Maecenas ornare ultrices laoreet. Phasellus euismod elementum tellus, nec facilisis arcu rhoncus vel. Cras lobortis risus sit amet convallis rhoncus. Sed aliquet sem vel elit porttitor blandit. Aliquam id lectus diam.";
        Appointment appointment = new Appointment("12345", new Date(), longDescription);
    }
}
