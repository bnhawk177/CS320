import java.util.Date;

public class Appointment {
    private final String appointmentID;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentID, Date appointmentDate, String description) {
        this.appointmentID = appointmentID;
        this.setAppointmentDate(appointmentDate);
        this.setDescription(description);
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        }
        this.appointmentDate = appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description == null || description.isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Description field cannot be null, empty or longer than 50 characters.");
        }
        this.description = description;
    }

	public void setDate(Date date) {
		// TODO Auto-generated method stub
		
	}

	public Object getDate() {
		// TODO Auto-generated method stub
		return null;
	}
}